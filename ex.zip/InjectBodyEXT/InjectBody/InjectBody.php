<?php

namespace Paymenter\Extensions\Others\InjectBody;

use App\Classes\Extension\Extension;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\HtmlString;

#[ExtensionMeta(
    name: 'InjectBody',
    description: 'Inject code into the body of every page',
    version: '1.0.0',
    author: 'JTD',
    url: 'https://justvikie.nl',
    icon: 'https://justvikie.nl/favicon.ico'
)]
class InjectBody extends Extension
{
    public function getConfig($values = []): array
    {
        return [
            [
                'name' => 'code',
                'type' => 'text',
                'label' => 'Code',
                'description' => 'This code will be injected into every page body.',
                'required' => true,
            ],
        ];
    }

    public function boot(): void
    {
        // Only inject for normal GET requests
        if (!request()->isMethod('GET')) {
            return;
        }

        $bodyScript = $this->getBodyScript();

        Event::listen('body', function () use ($bodyScript) {
            return ['view' => new HtmlString($bodyScript)];
        });
    }

    private function getBodyScript(): string
    {
        $code = trim((string) $this->getSetting('code'));

        if (empty($code)) {
            $code = '<script>console.log("InjectBody Extension is active - set your code in the settings!");</script>';
        }

        return <<<HTML
{$code}
HTML;
    }

    // Lifecycle hooks (can be expanded later)
    public function enabled(): void {}
    public function disabled(): void {}
    public function updated(): void {}
    public function install(): void {}

    private function getSetting(string $key, $default = null)
    {
        return $this->config($key, $default);
    }
}
