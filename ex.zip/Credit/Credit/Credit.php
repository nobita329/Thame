<?php
// /var/www/paymenter/extensions/Others/Credit/Credit.php

namespace Paymenter\Extensions\Others\Credit;

use App\Classes\Extension\Extension;
use App\Events\User\Created as UserCreated;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Log;

class Credit extends Extension
{
    /**
     * Get all the configuration for the extension
     *
     * @param  array  $values
     * @return array
     */
    public function getConfig($values = [])
    {
        return [
            [
                'name' => 'start_credit',
                'type' => 'number',
                'label' => 'Initial Credits',
                'required' => true,
                'validation' => 'min:0',
                'description' => 'Amount of credit given to new users'
            ],
            [
                'name' => 'currency_code',
                'type' => 'text',
                'label' => 'Currency Code',
                'required' => true,
                'default' => 'USD',
                'description' => '3-letter currency code for credits'
            ]
        ];
    }

    public function boot()
    {
        Log::info('Credit extension initialized');

        Event::listen(UserCreated::class, function ($event) {
            try {
                $credits = (float) $this->config('start_credit');
                $currency = $this->config('currency_code', 'USD');
                $userId = $event->user->id;

                Log::info('Processing new user credits', [
                    'user_id' => $userId,
                    'amount' => $credits,
                    'currency' => $currency
                ]);

                if ($credits > 0) {
                    DB::table('credits')->insert([
                        'user_id' => $userId,
                        'currency_code' => $currency,
                        'amount' => $credits,
                        'created_at' => now(),
                        'updated_at' => now()
                    ]);

                    Log::info('Credits added successfully', [
                        'user_id' => $userId,
                        'amount' => $credits,
                        'currency' => $currency
                    ]);
                }
            } catch (\Exception $e) {
                Log::error('Credit extension error', [
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
            }
        });
    }
}