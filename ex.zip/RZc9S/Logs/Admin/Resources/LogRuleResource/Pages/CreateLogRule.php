<?php

namespace Paymenter\Extensions\Others\Logs\Admin\Resources\LogRuleResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Paymenter\Extensions\Others\Logs\Admin\Resources\LogRuleResource;

class CreateLogRule extends CreateRecord
{
    protected static string $resource = LogRuleResource::class;
}

