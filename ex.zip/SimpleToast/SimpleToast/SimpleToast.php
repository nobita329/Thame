<?php

namespace Paymenter\Extensions\Others\SimpleToast;

use App\Classes\Extension\Extension;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\HtmlString;

#[ExtensionMeta(
    name: 'SimpleToast',
    description: 'Displays a configurable popup notification (info, success, warning, error) with optional link and position.',
    version: '1.3',
    author: 'JTD',
    url: 'https://justvikie.nl',
    icon: 'https://justvikie.nl/favicon.ico'
)]
class SimpleToast extends Extension
{
    public function getConfig($values = []): array
    {
        return [
            [
                'name' => 'enabled',
                'type' => 'checkbox',
                'label' => 'Enable Popup',
                'description' => 'If unchecked, no popup will appear.',
                'required' => false,
            ],
            [
                'name' => 'message_text',
                'type' => 'text',
                'label' => 'Popup Message',
                'description' => 'Main message displayed inside the popup.',
                'required' => true,
            ],
            [
                'name' => 'popup_type',
                'type' => 'select',
                'label' => 'Popup Type',
                'description' => 'Choose the popup style.',
                'options' => [
                    'info' => 'Info (blue)',
                    'success' => 'Success (green)',
                    'warning' => 'Warning (orange)',
                    'error' => 'Error (red)',
                ],
                'required' => true,
                'value' => $values['popup_type'] ?? 'info',
            ],
            [
                'name' => 'popup_position',
                'type' => 'select',
                'label' => 'Popup Position',
                'options' => [
                    'top-left' => 'Top Left',
                    'top-right' => 'Top Right',
                    'bottom-left' => 'Bottom Left',
                    'bottom-right' => 'Bottom Right',
                    'center' => 'Center',
                ],
                'required' => true,
                'value' => $values['popup_position'] ?? 'bottom-right',
            ],
            [
                'name' => 'popup_link',
                'type' => 'text',
                'label' => 'Optional Link',
                'description' => 'Optional link displayed under the message.',
                'required' => false,
                'value' => $values['popup_link'] ?? '',
            ],
            [
                'name' => 'auto_dismiss',
                'type' => 'number',
                'label' => 'Auto dismiss (seconds, 0 = disabled)',
                'required' => false,
                'value' => $values['auto_dismiss'] ?? 7,
            ],
        ];
    }

    public function boot(): void
    {
        if (!request()->isMethod('GET')) return;

        $bodyScript = $this->getBodyScript();
        Event::listen('body', function () use ($bodyScript) {
            return ['view' => new HtmlString($bodyScript)];
        });
    }

    private function getBodyScript(): string
    {
        // prepare PHP values and json-encode for JS safety
        $enabled = (bool)$this->getSetting('enabled', false);
        $type = (string)$this->getSetting('popup_type', 'info');
        $message = (string)$this->getSetting('message_text', '');
        $link = (string)$this->getSetting('popup_link', '');
        $position = (string)$this->getSetting('popup_position', 'bottom-right');
        $autoDismiss = (int)$this->getSetting('auto_dismiss', 7);

        $enabled_js = json_encode($enabled);
        $type_js = json_encode($type);
        $message_js = json_encode($message);
        $link_js = json_encode($link);
        $position_js = json_encode($position);
        $autoDismiss_js = json_encode($autoDismiss);

        return <<<HTML
<script>
(function(){
  const CONFIG = {
    enabled: $enabled_js,
    type: $type_js,
    message: $message_js,
    link: $link_js,
    position: $position_js,
    autoDismiss: $autoDismiss_js
  };

  function showPopup({ type = "info", enabled = true, message = "", link = "", position = "bottom-right", autoDismiss = 7 } = {}) {
    if (!enabled) return;

    const colors = {
      info:   { bg: "#e0f0ff", border: "#60a5fa", icon: "ℹ️" },
      success:{ bg: "#e6ffed", border: "#22c55e", icon: "✅" },
      warning:{ bg: "#fff7e0", border: "#f59e0b", icon: "⚠️" },
      error:  { bg: "#ffe4e6", border: "#ef4444", icon: "❌" }
    };

    const { bg, border, icon } = colors[type] || colors.info;

    // container element
    const container = document.createElement("div");
    container.style.position = "fixed";
    container.style.zIndex = 999999;
    container.style.pointerEvents = "none";
    container.style.display = "flex";
    container.style.flexDirection = "column";
    container.style.gap = "8px";
    container.style.maxWidth = "100%";
    container.style.boxSizing = "border-box";

    // position
    switch (position) {
      case "top-left":
        container.style.top = "20px"; container.style.left = "20px"; break;
      case "top-right":
        container.style.top = "20px"; container.style.right = "20px"; break;
      case "bottom-left":
        container.style.bottom = "20px"; container.style.left = "20px"; break;
      case "center":
        container.style.top = "50%"; container.style.left = "50%";
        container.style.transform = "translate(-50%, -50%)"; break;
      default:
        container.style.bottom = "20px"; container.style.right = "20px"; break;
    }

    // single popup element
    const popup = document.createElement("div");
    popup.style.pointerEvents = "auto";
    popup.style.display = "flex";
    popup.style.alignItems = "center";
    popup.style.gap = "10px";
    popup.style.background = bg;
    popup.style.borderLeft = "6px solid " + border;
    popup.style.color = "#222";
    popup.style.fontFamily = "system-ui, sans-serif";
    popup.style.fontSize = "15px";
    popup.style.padding = "12px 16px";
    popup.style.borderRadius = "8px";
    popup.style.boxShadow = "0 4px 10px rgba(0,0,0,0.15)";
    popup.style.maxWidth = "360px";
    popup.style.transform = "scale(0.95)";
    popup.style.opacity = "0";
    popup.style.transition = "all 0.25s ease";

    // icon
    const iconSpan = document.createElement("span");
    iconSpan.style.fontSize = "20px";
    iconSpan.textContent = icon;
    popup.appendChild(iconSpan);

    // message container
    const msg = document.createElement("div");
    msg.style.flex = "1";
    // insert message as text to avoid accidental HTML execution from unknown sources
    // if you want to allow HTML, change to msg.innerHTML = message;
    msg.textContent = message || "";
    popup.appendChild(msg);

    // optional link
    if (link) {
      const linkEl = document.createElement("a");
      linkEl.href = link;
      linkEl.target = "_blank";
      linkEl.rel = "noopener noreferrer";
      linkEl.textContent = "Open link →";
      linkEl.style.display = "block";
      linkEl.style.marginTop = "6px";
      linkEl.style.color = border;
      linkEl.style.textDecoration = "none";
      msg.appendChild(linkEl);
    }

    // close button
    const btn = document.createElement("button");
    btn.type = "button";
    btn.innerHTML = "&times;";
    btn.setAttribute("aria-label", "close");
    btn.style.background = "none";
    btn.style.border = "none";
    btn.style.fontSize = "18px";
    btn.style.cursor = "pointer";
    btn.style.color = "#555";
    btn.style.marginLeft = "8px";
    popup.appendChild(btn);

    container.appendChild(popup);
    document.body.appendChild(container);

    // animate in
    requestAnimationFrame(() => {
      popup.style.opacity = "1";
      popup.style.transform = "scale(1)";
    });

    const remove = () => {
      popup.style.opacity = "0";
      popup.style.transform = "scale(0.95)";
      setTimeout(() => {
        try { container.remove(); } catch(e) {}
      }, 260);
    };

    btn.addEventListener("click", remove);

    if (autoDismiss && Number(autoDismiss) > 0) {
      setTimeout(remove, Number(autoDismiss) * 1000);
    }
  }

  // show configured popup
  document.addEventListener("DOMContentLoaded", function() {
    showPopup({
      type: CONFIG.type,
      enabled: CONFIG.enabled,
      message: CONFIG.message,
      link: CONFIG.link,
      position: CONFIG.position,
      autoDismiss: CONFIG.autoDismiss
    });
  });
})();
</script>
HTML;
    }

    public function enabled(): void {}
    public function disabled(): void {}
    public function updated(): void {}
    public function install(): void {}

    private function getSetting(string $key, $default = null)
    {
        return $this->config($key, $default);
    }
}

