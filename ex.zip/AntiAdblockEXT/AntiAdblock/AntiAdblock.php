<?php

namespace Paymenter\Extensions\Others\AntiAdblock;

use App\Classes\Extension\Extension;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\HtmlString;

#[ExtensionMeta(
    name: 'AntiAdblock',
    description: 'Simple way to block users that have adblock enabled',
    version: '1.0.0',
    author: 'JTD',
    url: 'https://justvikie.nl',
    icon: 'https://justvikie.nl/favicon.ico'
)]
class AntiAdblock extends Extension
{
    public function getConfig($values = []): array
    {
        return [
            [
                'name' => 'source',
                'type' => 'select',
                'label' => 'Script Source',
                'description' => 'Choose the source for the ultiblock script',
                'options' => [
                    'js' => 'jtdmedia/ultiblock@main/ultiblock.js',
                    'minjs' => 'jtdmedia/ultiblock@main/ultiblock.min.js',
                    'minobjs' => 'jtdmedia/ultiblock@main/ultiblock.min.ob.js',
                    'custom' => 'Custom (enter below)',
                ],
                'required' => true,
                'value' => $values['source'] ?? 'minobjs',
            ],
            [
                'name' => 'custom_source',
                'type' => 'text',
                'label' => 'Custom Source',
                'description' => 'Optional custom source for ultiblock script (example: username/repo@branch/file.js)',
                'required' => false,
                'value' => $values['custom_source'] ?? '',
            ],
        ];
    }

    public function boot(): void
    {
        if (!request()->isMethod('GET')) return;

        $bodyScript = $this->getBodyScript();
        Event::listen('body', function () use ($bodyScript) {
            return ['view' => new HtmlString($bodyScript)];
        });
    }

    private function getBodyScript(): string
    {
        $source = (string)$this->getSetting('source', 'minobjs');
        $custom = trim((string)$this->getSetting('custom_source', ''));

        if ($source === 'custom' && $custom !== '') {
            $scriptSrc = "https://cdn.jsdelivr.net/gh/{$custom}";
        } else {
            $map = [
                'js' => 'jtdmedia/ultiblock@main/ultiblock.js',
                'minjs' => 'jtdmedia/ultiblock@main/ultiblock.min.js',
                'minobjs' => 'jtdmedia/ultiblock@main/ultiblock.min.ob.js',
            ];
            $repo = $map[$source] ?? $map['minobjs'];
            $scriptSrc = "https://cdn.jsdelivr.net/gh/{$repo}";
        }

        return <<<HTML
<script src="{$scriptSrc}" async></script>
HTML;
    }

    public function enabled(): void {}
    public function disabled(): void {}
    public function updated(): void {}
    public function install(): void {}

    private function getSetting(string $key, $default = null)
    {
        return $this->config($key, $default);
    }
}

