<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Livewire;

use Livewire\Component;

class Error extends Component
{
    public function render()
    {
        return <<<'blade'
<div class="container text-center p-5">
    <div class="alert alert-success" role="alert">
        <h1 class="display-4">Authorization required! ⚠️</h1>
        <article class="prose dark:prose-invert mb-2 max-w-full">
            You must be logged in to your account ⚠️
        </article>
        <hr class="my-4">
        <p>Please log in to your account before linking your Discord profile.</p>
        <a href="/login" class="btn btn-primary btn-lg">
            Go to Login 🔐
        </a>
    </div>
</div>
blade;
    }
}