<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Livewire;

use App\Models\Setting;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Models\LinkedRoleSetting;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Models\CustomErrorPage;
use Livewire\Component;

class CustomError extends Component
{
    public $errorTitle;
    public $errorMessage;
    public $errorAboveButtonText;
    public $errorButtonText;
    public $errorButtonLink;

    public function mount()
    {
        $selectedBotId = Setting::where('key', 'discord_bot_id')->value('value');
        if (!$selectedBotId) {
            abort(503, 'Service Unavailable: Unable to retrieve bot settings.');
        }

        $bot = LinkedRoleSetting::where('id', $selectedBotId)->first();
        if (!$bot) {
            abort(503, 'Service Unavailable: Invalid bot.');
        }

        $selectedCustomErrorPage = $bot->error_redirect_page ?? null;
        $customErrorPage = CustomErrorPage::where('key', $selectedCustomErrorPage)->first();

        if ($customErrorPage) {
            $this->errorTitle = $customErrorPage->title;
            $this->errorMessage = $customErrorPage->text;
            $this->errorAboveButtonText = $customErrorPage->text_above_button;
            $this->errorButtonText = $customErrorPage->button_text;
            $this->errorButtonLink = $customErrorPage->button_link;
        } else {
            abort(404);
        }
    }

    public function render()
    {
        return <<<'blade'
<div class="container text-center p-5">
    <div class="alert alert-success" role="alert">
        <h1 class="display-4">{{ $errorTitle }}</h1>
        <article class="prose dark:prose-invert mb-2 max-w-full">
            {!! $errorMessage !!}
        </article>
        <hr class="my-4">
        <p>{{ $errorAboveButtonText }}</p>
        <a href="{{ $errorButtonLink }}" class="btn btn-primary btn-lg">
            {{ $errorButtonText }}
        </a>
    </div>
</div>
blade;
    }
}