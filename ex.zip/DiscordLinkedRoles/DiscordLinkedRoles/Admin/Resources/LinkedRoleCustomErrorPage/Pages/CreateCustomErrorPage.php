<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage\Pages;

use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage;
use Filament\Resources\Pages\CreateRecord;

class CreateCustomErrorPage extends CreateRecord
{
    protected static string $resource = LinkedRoleCustomErrorPage::class;
}