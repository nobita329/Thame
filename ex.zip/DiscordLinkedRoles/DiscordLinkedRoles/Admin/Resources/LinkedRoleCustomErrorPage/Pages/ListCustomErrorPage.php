<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage\Pages;

use Filament\Actions\CreateAction;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListCustomErrorPage extends ListRecords
{
    protected static string $resource = LinkedRoleCustomErrorPage::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}