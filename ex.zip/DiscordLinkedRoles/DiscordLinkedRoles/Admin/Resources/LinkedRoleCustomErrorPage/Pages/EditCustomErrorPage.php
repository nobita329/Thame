<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage\Pages;

use Filament\Actions\DeleteAction;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditCustomErrorPage extends EditRecord
{
    protected static string $resource = LinkedRoleCustomErrorPage::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}