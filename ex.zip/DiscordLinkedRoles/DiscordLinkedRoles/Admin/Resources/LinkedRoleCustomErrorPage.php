<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources;

use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\RichEditor;
use Filament\Tables\Columns\TextColumn;
use Filament\Actions\EditAction;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage\Pages\ListCustomErrorPage;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage\Pages\CreateCustomErrorPage;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage\Pages\EditCustomErrorPage;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomErrorPage\Pages;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Models\CustomErrorPage;
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class LinkedRoleCustomErrorPage extends Resource
{
    protected static ?string $model = CustomErrorPage::class;

    protected static string | \UnitEnum | null $navigationGroup = 'Discord Linked Roles';
    protected static ?string $navigationLabel = 'Custom Error Pages';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-m-newspaper';
    protected static ?int $navigationSort = 3;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('key')->required()->rule('regex:/^[a-z0-9_-]+$/')->rule('not_in:home,error')->default('demo'),
                TextInput::make('name')->required()->default('Demo'),
                TextInput::make('title')->columnSpanFull()->required()->default('Authorization required! ⚠️'),
                RichEditor::make('text')->columnSpanFull()->label('Content')->required()->default('You must be logged in to your account ⚠️'),
                TextInput::make('text_above_button')->label('Text above the button')->required()->default('Please log in to your account before linking your Discord profile.'),
                TextInput::make('button_text')->label('Button Text')->required()->default('Go to Login 🔐'),
                TextInput::make('button_link')->columnSpanFull()->label('Button URL')->required()->default('/login'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('key'),
                TextColumn::make('name'),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListCustomErrorPage::route('/'),
            'create' => CreateCustomErrorPage::route('/create'),
            'edit' => EditCustomErrorPage::route('/{record}/edit'),
        ];
    }

    public static function canAccess(): bool
    {
        $user = auth()->user();
        return $user && $user->hasPermission('*');
    }
}