<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources;

use Filament\Schemas\Schema;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\RichEditor;
use Filament\Tables\Columns\TextColumn;
use Filament\Actions\EditAction;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomPage\Pages\ListCustomPage;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomPage\Pages\CreateCustomPage;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomPage\Pages\EditCustomPage;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRoleCustomPage\Pages;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Models\CustomPage;
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class LinkedRoleCustomPage extends Resource
{
    protected static ?string $model = CustomPage::class;

    protected static string | \UnitEnum | null $navigationGroup = 'Discord Linked Roles';
    protected static ?string $navigationLabel = 'Custom Pages';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-m-newspaper';
    protected static ?int $navigationSort = 2;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('key')->required()->rule('regex:/^[a-z0-9_-]+$/')->rule('not_in:home,callback')->default('demo'),
                TextInput::make('name')->required()->default('Demo'),
                TextInput::make('title')->columnSpanFull()->required()->default('You have successfully connected your discord! 🎉'),
                RichEditor::make('text')->columnSpanFull()->label('Content')->required()->default('🎉 Congratulations! Your Discord account is now successfully linked to your account. You are one step closer to enjoying exclusive roles and perks! 💎'),
                TextInput::make('text_above_button')->label('Text above the button')->required()->default('Click the button below to go back to Discord and claim your role. ⬇️'),
                TextInput::make('button_text')->label('Button Text')->required()->default('Go to Discord 🚀'),
                TextInput::make('button_link')->columnSpanFull()->label('Button URL')->required()->default('discord://discord.com/channels/@me'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('key'),
                TextColumn::make('name'),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListCustomPage::route('/'),
            'create' => CreateCustomPage::route('/create'),
            'edit' => EditCustomPage::route('/{record}/edit'),
        ];
    }

    public static function canAccess(): bool
    {
        $user = auth()->user();
        return $user && $user->hasPermission('*');
    }
}