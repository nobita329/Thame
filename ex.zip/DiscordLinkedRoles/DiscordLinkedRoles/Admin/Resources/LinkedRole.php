<?php

namespace Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources;

use Filament\Schemas\Schema;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Tables\Columns\TextColumn;
use Filament\Actions\EditAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Illuminate\Database\QueryException;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRole\Pages\AdminLinkedRoles;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRole\Pages\AdminLinkedRolesCreate;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRole\Pages\AdminLinkedRolesEdit;
use App\Models\Setting;
use Filament\Forms;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Actions\Action as FormAction;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Admin\Resources\LinkedRole\Pages;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Models\LinkedRoleSetting;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Models\CustomPage;
use Paymenter\Extensions\Others\DiscordLinkedRoles\Models\CustomErrorPage;
use Illuminate\Support\HtmlString;
use Illuminate\Support\Facades\Http;

class LinkedRole extends Resource
{
    protected static ?string $model = LinkedRoleSetting::class;
    protected static string | \UnitEnum | null $navigationGroup = 'Discord Linked Roles';
    protected static ?string $navigationLabel = 'Linked Roles';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-o-users';
    protected static ?int $navigationSort = 1;

    public static function form(Schema $schema): Schema
    {
        $pages = CustomPage::all(['key', 'name']);
        $pageOptions = $pages->filter(fn($page) => !empty($page->name))->pluck('name', 'key')->toArray();

        $errorPages = CustomErrorPage::all(['key', 'name']);
        $errorPageOptions = $errorPages->filter(fn($page) => !empty($page->name))->pluck('name', 'key')->toArray();
        

        return $schema->components([
            Tabs::make('Linked Roles')
                ->id('linked-roles')
                ->persistTab()
                ->tabs([
                    Tab::make('General')->schema([
                        TextInput::make('discordlinkedroles_bot_name')
                            ->label('Bot Name')
                            ->placeholder('Give the bot a recognizable name for all settings.')
                            ->required(),
                    ]),
                    Tab::make('Bot Settings')->schema([
                        TextInput::make('discordlinkedroles_client_id')
                            ->label('Discord Client ID')
                            ->placeholder('1296581432969265306')
                            ->required(),
                        TextInput::make('discordlinkedroles_client_secret')
                            ->label('Discord Client Secret')
                            ->placeholder('your-client-secret-here')
                            ->required()
                            ->password()
                            ->revealable(),
                        TextInput::make('discordlinkedroles_bot_token')
                            ->label('Discord Bot Token')
                            ->placeholder('your-bot-token-here')
                            ->required()
                            ->password()
                            ->revealable(),
                    ]),
                    Tab::make('Sync Settings')->schema([
                        TextInput::make('syncedwithpaymenter')
                            ->label('Is registered on the website')
                            ->placeholder('Enter here the name that appears in Discord as a requirement for the role')
                            ->default('Is registered on the website')
                            ->required(),
                        Textarea::make('syncedwithpaymenter_description')
                            ->label('Description')
                            ->placeholder('Enter here the description that appears in Discord as a requirement for the role')
                            ->default('Is logged in on the website')
                            ->required(),
                        TextInput::make('activeproducts')
                            ->label('Active Products')
                            ->placeholder('Enter here the name that appears in Discord as a requirement for the role')
                            ->default('Active Products')
                            ->required(),
                        Textarea::make('activeproducts_description')
                            ->label('Description')
                            ->placeholder('Enter here the description that appears in Discord as a requirement for the role')
                            ->default('How many active products the user has')
                            ->required(),
                    ]),
                    Tab::make('Api Settings')->schema([
                        Select::make('api_url')
                            ->label('Api URL')
                            ->options(['discord.com' => 'Discord.com'])
                            ->default('discord.com')
                            ->searchable()
                            ->required(),
                        Select::make('api_url_version')
                            ->label('Api version')
                            ->options([
                                'v10' => 'v10 (Available)',
                                'v9' => 'v9 (Available)',
                                'v8' => 'v8 (Deprecated)',
                                'v7' => 'v7 (Deprecated)',
                                'v6' => 'v6 (Deprecated - Default)',
                            ])
                            ->default('v6')
                            ->searchable()
                            ->required(),
                    ]),
                    Tab::make('Route Settings')->schema([
                        TextInput::make('linkedroles_url')
                            ->label('Linked Roles Verification URL')
                            ->placeholder('Enter the route for the linked roles (e.g., /linkedroles)')
                            ->default('/linkedroles')
                            ->required()
                            ->rules(['regex:/^\/[a-zA-Z\/]*$/']),
                        TextInput::make('linkedroles_callback_url')
                            ->label('Linked Roles Callback URL')
                            ->placeholder('Enter the route for the callback (e.g., /linkedroles/callback)')
                            ->default('/linkedroles/callback')
                            ->required()
                            ->rules(['regex:/^\/[a-zA-Z\/]*$/']),
                        Select::make('callback_redirect_page')
                            ->label('Landing Page')
                            ->options([
                                'Basic Pages' => [
                                    'home' => 'Home Page',
                                    'callback' => 'Callback Page',
                                ],
                                'Custom Pages' => $pageOptions,
                            ])
                            ->default('callback')
                            ->searchable()
                            ->required(),
                        TextInput::make('success_route')
                            ->label('Success Route (Custom Page Only)')
                            ->placeholder('Enter the route for the success page (e.g., /linkedroles/success)')
                            ->nullable()
                            ->default('/linkedroles/success')
                            ->rules(['regex:/^\/[a-zA-Z\/]*$/']),
                        Select::make('error_redirect_page')
                            ->label('Error Landing Page')
                            ->options([
                                'Basic Pages' => [
                                    'error' => 'Error Page',
                                ],
                                'Custom Error Pages' => $errorPageOptions,
                            ])
                            ->default('error')
                            ->searchable()
                            ->required(),
                        TextInput::make('error_route')
                            ->label('Error Route (Custom Error Page Only)')
                            ->placeholder('Enter the route for the error page (e.g., /linkedroles/error)')
                            ->nullable()
                            ->default('/linkedroles/error')
                            ->rules(['regex:/^\/[a-zA-Z\/]*$/']),
                    ]),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('discordlinkedroles_bot_name')
                    ->label('Bot Name')
                    ->searchable(),
                TextColumn::make('discordlinkedroles_client_id')
                    ->label('Discord Client ID')
                    ->searchable(),
                TextColumn::make('discordlinkedroles_client_secret')
                    ->label('Discord Client Secret')
                    ->getStateUsing(fn($record) => 'Hidden for security reasons')
                    ->tooltip('You can only see it in the edit tab, as it is hidden for security reasons.')
                    ->searchable(),
            ])
            ->recordActions([
                \Filament\Actions\Action::make('sync_now')
                    ->label('Sync Now')
                    ->icon('heroicon-o-arrow-path')
                    ->action(function ($record) {
                        $url = 'https://' . $record->api_url . '/api/' . $record->api_url_version . '/applications/' . $record->discordlinkedroles_client_id . '/role-connections/metadata';

                        $response = Http::withHeaders([
                            'Authorization' => 'Bot ' . $record->discordlinkedroles_bot_token,
                        ])->put($url, [
                            [
                                'key' => 'syncedwithpaymenter',
                                'name' => $record->syncedwithpaymenter,
                                'description' => $record->syncedwithpaymenter_description,
                                'type' => 7,
                            ],
                            [
                                'key' => 'activeproducts',
                                'name' => $record->activeproducts,
                                'description' => $record->activeproducts_description,
                                'type' => 2,
                            ]
                        ]);

                        if ($response->failed()) {
                            Notification::make()
                                ->title('Sync Failed')
                                ->danger()
                                ->body('Something went wrong while pushing the linked roles to Discord for: ' . $record->discordlinkedroles_bot_name)
                                ->send();
                            return;
                        }

                        Notification::make()
                            ->title('Sync Successful')
                            ->success()
                            ->body('Linked roles have been pushed to Discord for: ' . $record->discordlinkedroles_bot_name)
                            ->send();
                    }),
                EditAction::make(),
                DeleteAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ])
            ]);
    }

    public static function canAccess(): bool
    {
        $user = auth()->user();
        return $user && $user->hasPermission('*');
    }

    public static function getPages(): array
    {
        try {
            $bots = LinkedRoleSetting::all();
        } catch (QueryException $e) {
            $bots = collect();
        }

        return [
            'index' => AdminLinkedRoles::route('/'),
            'create' => AdminLinkedRolesCreate::route('create/settings'),
            'edit' => AdminLinkedRolesEdit::route('{record}/settings'),
        ];
    }
}