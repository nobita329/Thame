<?php

namespace Paymenter\Extensions\Others\SocialBase;

use App\Classes\Extension\Extension;
use Exception;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\View;
use Illuminate\Support\HtmlString;
use Livewire\Livewire;

use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;
use Paymenter\Extensions\Others\SocialBase\Models\ProfileComment;
use Illuminate\Support\Facades\Auth;
use App\Events\Invoice\Paid as InvoicePaid;
use App\Events\Order\Created as OrderCreated;
use App\Events\Service\Updated as ServiceUpdated;
use Paymenter\Extensions\Others\SocialBase\Listeners\AutomationListener;
use Paymenter\Extensions\Others\SocialBase\Listeners\NotificationListener;

class SocialBase extends Extension
{
    public function boot()
    {
        // Preload config to ensure it's available for closures and avoid backtrace issues
        $this->config('enable_profiles');

        // Register Admin Service Provider
        // app()->register(\Paymenter\Extensions\Others\SocialBase\Admin\AdminServiceProvider::class);

        // Register routes
        require __DIR__ . '/routes/web.php';
        
        // Register middleware
        app('router')->aliasMiddleware('require.profile', \Paymenter\Extensions\Others\SocialBase\Http\Middleware\RequireProfile::class);
        
        // Register views
        View::addNamespace('socialbase', __DIR__ . '/resources/views');

        // Register Livewire components
        Livewire::component('socialbase.profile-view', \Paymenter\Extensions\Others\SocialBase\Livewire\ProfileView::class);
        Livewire::component('socialbase.profile-edit', \Paymenter\Extensions\Others\SocialBase\Livewire\ProfileEdit::class);
        Livewire::component('socialbase.profile-settings', \Paymenter\Extensions\Others\SocialBase\Livewire\ProfileSettings::class);
        Livewire::component('socialbase.profile-comments', \Paymenter\Extensions\Others\SocialBase\Livewire\ProfileComments::class);
        Livewire::component('socialbase.profile-tabs', \Paymenter\Extensions\Others\SocialBase\Livewire\ProfileTabs::class);
        Livewire::component('socialbase.messaging-interface', \Paymenter\Extensions\Others\SocialBase\Livewire\MessagingInterface::class);
        Livewire::component('socialbase.messaging-bubble', \Paymenter\Extensions\Others\SocialBase\Livewire\MessagingBubble::class);
        Livewire::component('socialbase.report-message', \Paymenter\Extensions\Others\SocialBase\Livewire\ReportMessage::class);
        Livewire::component('socialbase.report-user', \Paymenter\Extensions\Others\SocialBase\Livewire\ReportUser::class);
        Livewire::component('socialbase.create-group', \Paymenter\Extensions\Others\SocialBase\Livewire\CreateGroup::class);
        Livewire::component('socialbase.user-directory', \Paymenter\Extensions\Others\SocialBase\Livewire\UserDirectory::class);
        
        // Register policies
        Gate::policy(UserProfile::class, Policies\UserProfilePolicy::class);
        Gate::policy(ProfileComment::class, Policies\ProfileCommentPolicy::class);
        Gate::policy(Models\Message::class, Policies\MessagePolicy::class);
        Gate::policy(Models\MessageReport::class, Policies\MessageReportPolicy::class);
        Gate::policy(Models\UserReport::class, Policies\UserReportPolicy::class);

        // Register Automation Listeners
        Event::listen(InvoicePaid::class, [AutomationListener::class, 'handleInvoicePaid']);
        Event::listen(OrderCreated::class, [AutomationListener::class, 'handleOrderCreated']);
        Event::listen(ServiceUpdated::class, [AutomationListener::class, 'handleServiceUpdated']);

        // Register Notification Listener for new messages
        Event::listen('socialbase.message.sent', [NotificationListener::class, 'handle']);
        Event::listen('socialbase.system_message.sent', [NotificationListener::class, 'handleSystemMessage']);

        // Listen for user reports to send confirmation
        Event::listen('socialbase.user.reported', function ($report) {
            // Check if MessagingHelper is available
            if (!class_exists('\Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper')) {
                return;
            }

            // Send confirmation to reporter
            try {
                $reasonText = ucfirst(str_replace('_', ' ', $report->reason));
                
                $message = "**Report Received - We're Reviewing It**\n\n";
                $message .= "Thank you for reporting a user. We take all reports seriously and our moderation team will review it shortly.\n\n";
                $message .= "Report Details:\n";
                $message .= "- Reason: {$reasonText}\n";
                $message .= "- Report ID: #{$report->id}\n\n";
                $message .= "You will receive another message once our team has reviewed your report.";
                
                \Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper::sendSystemMessage(
                    $report->reported_by,
                    $message,
                    'user_report_confirmation'
                );
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::warning('SocialBase: Failed to send user report confirmation - ' . $e->getMessage());
            }
        });

        // Listen for message reports to send confirmation
        Event::listen('socialbase.message.reported', function ($report) {
            // Check if MessagingHelper is available
            if (!class_exists('\Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper')) {
                return;
            }

            // Send confirmation to reporter
            try {
                $reasonText = ucfirst(str_replace('_', ' ', $report->reason));
                
                $message = "**Report Received - We're Reviewing It**\n\n";
                $message .= "Thank you for reporting a message. We take all reports seriously and our moderation team will review it shortly.\n\n";
                $message .= "Report Details:\n";
                $message .= "- Reason: {$reasonText}\n";
                $message .= "- Report ID: #{$report->id}\n\n";
                $message .= "You will receive another message once our team has reviewed your report.";
                
                \Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper::sendSystemMessage(
                    $report->reported_by,
                    $message,
                    'message_report_confirmation'
                );
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::warning('SocialBase: Failed to send report confirmation - ' . $e->getMessage());
            }
        });

        // Listen for report review decisions to notify reporter
        Event::listen('socialbase.message.report_reviewed', function ($report, $decision) {
            // Check if MessagingHelper is available
            if (!class_exists('\Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper')) {
                return;
            }

            // Send decision notification to reporter
            try {
                $reasonText = ucfirst(str_replace('_', ' ', $report->reason));
                
                if ($decision === 'dismissed') {
                    $message = "**Report Update: No Action Taken**\n\n";
                    $message .= "Thank you for your report (ID: #{$report->id}).\n\n";
                    $message .= "After review, our moderation team has determined that the reported message does not violate our community guidelines. ";
                    $message .= "The message will remain visible.\n\n";
                    $message .= "Report Reason: {$reasonText}\n\n";
                    $message .= "If you believe this decision was made in error, please contact our support team.";
                } else {
                    // Reviewed or action taken
                    $actionTaken = 'unknown';
                    if ($report->message) {
                        switch ($report->message->moderation_status) {
                            case 'deleted':
                                $actionTaken = 'The reported message has been removed';
                                break;
                            case 'flagged':
                                $actionTaken = 'The message has been flagged for review';
                                break;
                            case 'approved':
                                $actionTaken = 'The message has been reviewed and approved';
                                break;
                            default:
                                $actionTaken = 'Appropriate action has been taken';
                        }
                    }
                    
                    $message = "**Report Update: Action Taken**\n\n";
                    $message .= "Thank you for your report (ID: #{$report->id}).\n\n";
                    $message .= "Our moderation team has reviewed your report and taken action.\n\n";
                    $message .= "Action Taken: {$actionTaken}\n";
                    $message .= "Report Reason: {$reasonText}\n\n";
                    $message .= "We appreciate your help in keeping our community safe and respectful.";
                }
                
                \Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper::sendSystemMessage(
                    $report->reported_by,
                    $message,
                    'message_report_decision'
                );
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::warning('SocialBase: Failed to send report decision - ' . $e->getMessage());
            }
        });

        // Listen for user report review decisions to notify reporter
        Event::listen('socialbase.user.report_reviewed', function ($report) {
            // Check if MessagingHelper is available
            if (!class_exists('\Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper')) {
                return;
            }

            // Send decision notification to reporter
            try {
                $reasonText = ucfirst(str_replace('_', ' ', $report->reason));
                $reportedUserName = $report->reportedUser ? $report->reportedUser->name : 'User';
                
                $message = "**User Report Update - Decision Made**\n\n";
                $message .= "Thank you for your report (ID: #{$report->id}) regarding {$reportedUserName}.\n\n";
                $message .= "Our moderation team has reviewed your report.\n\n";
                $message .= "Report Reason: {$reasonText}\n";
                $message .= "Status: " . ucfirst(str_replace('_', ' ', $report->status)) . "\n\n";
                
                if ($report->status === 'action_taken') {
                    $message .= "Appropriate action has been taken based on our community guidelines. ";
                    $message .= "We appreciate your help in keeping our community safe.\n\n";
                } elseif ($report->status === 'no_action') {
                    $message .= "After careful review, our team determined that no policy violation occurred. ";
                    $message .= "If you have additional concerns, please contact our support team.\n\n";
                } elseif ($report->status === 'dismissed') {
                    $message .= "This report has been dismissed. If you believe this decision was made in error, ";
                    $message .= "please contact our support team.\n\n";
                }
                
                $message .= "Thank you for contributing to a safer community.";
                
                \Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper::sendSystemMessage(
                    $report->reported_by,
                    $message,
                    'user_report_decision'
                );
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::warning('SocialBase: Failed to send user report decision - ' . $e->getMessage());
            }
        });

        // Listen for comment approval to send notifications
        Event::listen('socialbase.comment.approved', function ($comment) {
            // Don't send message to user's own profile
            if ($comment->user_id === $comment->profile->user_id) {
                return;
            }

            // Check if MessagingHelper is available
            if (!class_exists('\Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper')) {
                return;
            }

            // Send message to profile owner
            try {
                $commenterName = $comment->user ? $comment->user->name : 'Someone';
                $commentPreview = substr($comment->content, 0, 100) . (strlen($comment->content) > 100 ? '...' : '');
                $profileUrl = route('socialbase.profile.show', $comment->profile->user_id);
                
                $message = "**New Comment on Your Profile**\n\n";
                $message .= "{$commenterName} commented on your profile:\n\n\"{$commentPreview}\"\n\nView your profile: {$profileUrl}";
                
                \Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper::sendSystemMessage(
                    $comment->profile->user_id,
                    $message,
                    'profile_comment_notification'
                );
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::warning('SocialBase: Failed to send comment notification - ' . $e->getMessage());
            }
        });

        // Listen for permissions event
        Event::listen('permissions', function () {
            return [
                // Profile Permissions
                'socialbase.profiles.view' => 'View User Profiles (Admin)',
                'socialbase.profiles.create' => 'Create User Profiles',
                'socialbase.profiles.update' => 'Update User Profiles',
                'socialbase.profiles.delete' => 'Delete User Profiles',
                'socialbase.profiles.moderate' => 'Moderate User Profiles (Ban, Restrict, etc.)',
                
                // Comment Permissions
                'socialbase.comments.view' => 'View Profile Comments',
                'socialbase.comments.create' => 'Create Profile Comments',
                'socialbase.comments.update' => 'Update Profile Comments',
                'socialbase.comments.delete' => 'Delete Profile Comments',
                'socialbase.comments.moderate' => 'Moderate Profile Comments',
                
                // Message Permissions
                'socialbase.messages.view' => 'View Messages (Admin Panel)',
                'socialbase.messages.moderate' => 'Moderate Messages (Flag, Approve)',
                'socialbase.messages.delete' => 'Delete Messages',
                
                // Report Permissions
                'socialbase.reports.view' => 'View Message Reports',
                'socialbase.reports.review' => 'Review & Update Message Reports',
                'socialbase.reports.delete' => 'Delete Message Reports',
                
                // Conversation Permissions
                'socialbase.conversations.view' => 'View All Conversations',
                'socialbase.conversations.delete' => 'Delete Conversations',
            ];
        });

        // Listen for navigation event to add profiles to menu
        Event::listen('navigation.account-dropdown', function () {
            if (!Auth::check() || !$this->config('enable_profiles')) {
                return [];
            }
            
            return [
                'name' => 'My Profile',
                'route' => 'socialbase.profile.show',
                'params' => ['user' => Auth::id()],
                'icon' => 'ri-user-line',
            ];
        });

        // Add "My Profile" to the account sidebar navigation group
        Event::listen('navigation.account', function () {
            if (!Auth::check() || !$this->config('enable_profiles')) {
                return [];
            }

            return [
                [
                    'name' => 'My Profile',
                    'route' => 'socialbase.profile.show',
                    'params' => ['user' => Auth::id()],
                    'icon' => 'ri-user-line',
                    'priority' => 15,
                ],
            ];
        });

        // Listen for profile hooks - allows other extensions to add tabs/content
        Event::listen('socialbase.profile.tabs', function ($user) {
            return []; // Other extensions can return tabs here
        });

        Event::listen('socialbase.profile.content', function ($user, $tab) {
            return null; // Other extensions can return content for their tabs
        });

        // Add Messages to navigation
        Event::listen('navigation', function () {
            if (!Auth::check()) {
                return;
            }
			$items = [];
            
            if ($this->config('enable_messaging')) {
                // Get unread count
                $service = new \Paymenter\Extensions\Others\SocialBase\Services\MessagingService();
                $unreadCount = $service->getUnreadCount(Auth::id());

                $items[] = [
                    'name' => 'Messages' . ($unreadCount > 0 ? ' (' . $unreadCount . ')' : ''),
                    'route' => 'socialbase.messages.index',
                    'icon' => 'ri-message',
                    'separator' => false,
                ];
            }

            if ($this->config('show_user_directory') && $this->config('enable_profiles')) {
                $items[] = [
                    'name' => 'Community',
                    'route' => 'socialbase.profile.directory',
                    'icon' => 'ri-folder-user',
                    'separator' => false,
                ];
            }

            return $items;
        });

        // Add messaging bubble to body
        Event::listen('body', function () {
            if (!Auth::check() || !$this->config('enable_messaging')) {
                return null;
            }
            
            return [
                'view' => view('socialbase::bubble-wrapper')->render(),
                'priority' => 100,
            ];
        });
    }

    public function getDisplayName()
    {
        return 'Social Base';
    }

    public function getConfig($values = [])
    {
        try {
            return [
                [
                    'name' => 'enable_messaging',
                    'type' => 'checkbox',
                    'label' => 'Enable Messaging',
                    'description' => 'Allow users to send messages to each other',
                    'default' => true,
                ],
                [
                    'name' => 'enable_profiles',
                    'type' => 'checkbox',
                    'label' => 'Enable Profiles',
                    'description' => 'Allow users to have public profiles',
                    'default' => true,
                ],
                [
                    'name' => 'allow_profile_comments',
                    'type' => 'checkbox',
                    'label' => 'Allow Profile Comments',
                    'description' => 'Allow users to comment on each other\'s profiles',
                    'default' => true,
                ],
                [
                    'name' => 'require_approval_comments',
                    'type' => 'checkbox',
                    'label' => 'Require Comment Approval',
                    'description' => 'Require admin approval for profile comments',
                    'default' => false,
                ],
                [
                    'name' => 'max_avatar_size',
                    'type' => 'number',
                    'label' => 'Max Avatar Size (MB)',
                    'description' => 'Maximum file size for avatar uploads',
                    'default' => 5,
                ],
                [
                    'name' => 'max_banner_size',
                    'type' => 'number',
                    'label' => 'Max Banner Size (MB)',
                    'description' => 'Maximum file size for banner uploads',
                    'default' => 10,
                ],
                [
                    'name' => 'allowed_image_types',
                    'type' => 'text',
                    'label' => 'Allowed Image Types',
                    'description' => 'Comma-separated list of allowed image extensions',
                    'default' => 'jpg,jpeg,png,gif,webp',
                ],
                [
                    'name' => 'show_user_directory',
                    'type' => 'checkbox',
                    'label' => 'Show User Directory Page',
                    'description' => 'Add the community user list page to the navigation.',
                    'default' => false,
                ],
                [
                    'name' => 'Notice',
                    'type' => 'placeholder',
                    'label' => new HtmlString('Social Base provides user profiles, avatars, banners, and comments. Other extensions can hook into this to add additional profile tabs and functionality. User profiles can be accessed via /profile/{user_id} routes.'),
                ],
            ];
        } catch (Exception $e) {
            return [
                [
                    'name' => 'Notice',
                    'type' => 'placeholder',
                    'label' => new HtmlString('Social Base provides foundational social features for user profiles. You\'ll need to enable this extension above to get started.'),
                ],
            ];
        }
    }

    public function enabled()
    {
        // Run migrations
        $migrationPath = 'extensions/Others/SocialBase/database/migrations';
        
        Artisan::call('migrate', [
            '--path' => $migrationPath,
            '--force' => true
        ]);
    }
}