<?php

namespace Paymenter\Extensions\Others\SocialBase\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;

class Announcement extends Model
{
    protected $table = 'ext_social_announcements';

    protected $fillable = [
        'subject',
        'content',
        'recipients_type',
        'recipients_data',
        'sent_at',
        'sent_count',
        'created_by',
    ];

    protected $casts = [
        'recipients_data' => 'array',
        'sent_at' => 'datetime',
    ];

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
