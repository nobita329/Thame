<?php

namespace Paymenter\Extensions\Others\SocialBase\Models;

use Illuminate\Database\Eloquent\Model;

class Automation extends Model
{
    protected $table = 'ext_social_automations';

    protected $fillable = [
        'name',
        'event',
        'conditions',
        'template_subject',
        'template_content',
        'is_active',
    ];

    protected $casts = [
        'conditions' => 'array',
        'is_active' => 'boolean',
    ];
}
