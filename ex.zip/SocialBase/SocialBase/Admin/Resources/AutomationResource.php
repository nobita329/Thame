<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources;

use Filament\Forms\Components\KeyValue;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Actions\DeleteAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Table;
use Paymenter\Extensions\Others\SocialBase\Admin\Clusters\ProfilesCluster;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\AutomationResource\Pages;
use Paymenter\Extensions\Others\SocialBase\Models\Automation;

class AutomationResource extends Resource
{
    protected static ?string $model = Automation::class;
    protected static string|\BackedEnum|null $navigationIcon = 'ri-robot-line';
    protected static ?string $navigationLabel = 'Automations';
    // protected static ?string $cluster = ProfilesCluster::class;
    protected static string|\UnitEnum|null $navigationGroup = 'Social Base';
    protected static ?int $navigationSort = 30;

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('name')->required(),
            Select::make('event')
                ->options([
                    'invoice.paid' => 'Invoice Paid',
                    'order.created' => 'Order Created',
                    'service.activated' => 'Service Activated',
                    'cart.abandoned' => 'Cart Abandoned',
                ])
                ->required(),
            KeyValue::make('conditions')
                ->keyLabel('Property')
                ->valueLabel('Value')
                ->helperText('For cart.abandoned, add "delay_minutes" (e.g., 60).'),
            TextInput::make('template_subject')->required(),
            Textarea::make('template_content')->rows(5)->required()
                ->helperText('Available variables: {user_name}, {amount}, {id}, etc.'),
            Toggle::make('is_active')->default(true),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->searchable(),
            TextColumn::make('event'),
            ToggleColumn::make('is_active'),
        ])
        ->actions([
            EditAction::make(),
            DeleteAction::make(),
        ]);
    }
    
    public static function getPages(): array
    {
        return [
            'index' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\AutomationResource\Pages\ListAutomations::route('/'),
            'create' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\AutomationResource\Pages\CreateAutomation::route('/create'),
            'edit' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\AutomationResource\Pages\EditAutomation::route('/{record}/edit'),
        ];
    }
}
