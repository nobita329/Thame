<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Paymenter\Extensions\Others\SocialBase\Models\Announcement;
use Paymenter\Extensions\Others\SocialBase\Admin\Clusters\ProfilesCluster;
use App\Models\User;

class AnnouncementResource extends Resource
{
    protected static ?string $model = Announcement::class;
    protected static string|\BackedEnum|null $navigationIcon = 'ri-megaphone-line';
    protected static ?string $navigationLabel = 'Announcements';
    // protected static ?string $cluster = ProfilesCluster::class;
    protected static string|\UnitEnum|null $navigationGroup = 'Social Base';
    protected static ?int $navigationSort = 40;

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('subject')->required(),
            Textarea::make('content')->rows(5)->required(),
            Select::make('recipients_type')
                ->options([
                    'all' => 'All Users',
                    'selected' => 'Selected Users',
                ])
                ->required()
                ->reactive(),
            Select::make('recipients_data')
                ->label('Select Users')
                ->multiple()
                ->options(User::selectRaw("CONCAT(first_name, ' ', last_name) as full_name, id")->pluck('full_name', 'id'))
                ->visible(fn ($get) => $get('recipients_type') === 'selected'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('subject')->searchable(),
            TextColumn::make('sent_at')->dateTime(),
            TextColumn::make('sent_count'),
            TextColumn::make('creator.name')->label('Sent By'),
        ])
        ->actions([
            \Filament\Actions\ViewAction::make(),
            \Filament\Actions\DeleteAction::make(),
        ]);
    }
    
    public static function getPages(): array
    {
        return [
            'index' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\AnnouncementResource\Pages\ListAnnouncements::route('/'),
            'create' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\AnnouncementResource\Pages\CreateAnnouncement::route('/create'),
        ];
    }
}
