<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\AnnouncementResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\AnnouncementResource;
use Filament\Actions\CreateAction;

class ListAnnouncements extends ListRecords
{
    protected static string $resource = AnnouncementResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}
