<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\AnnouncementResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\AnnouncementResource;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Services\MessagingService;
use App\Models\User;

class CreateAnnouncement extends CreateRecord
{
    protected static string $resource = AnnouncementResource::class;

    protected function handleRecordCreation(array $data): Model
    {
        // 1. Create the Announcement model.
        $data['created_by'] = Auth::id();
        
        /** @var \Paymenter\Extensions\Others\SocialBase\Models\Announcement $record */
        $record = static::getModel()::create($data);

        // 2. Logic to send messages
        $recipientsType = $record->recipients_type;
        $recipientsData = $record->recipients_data;
        $content = $record->content;
        
        $users = collect();

        if ($recipientsType === 'all') {
            $users = User::cursor(); 
        } elseif ($recipientsType === 'selected') {
            if (is_array($recipientsData)) {
                $users = User::whereIn('id', $recipientsData)->cursor();
            }
        }

        $messagingService = new MessagingService();
        $count = 0;

        foreach ($users as $user) {
            $messagingService->sendSystemMessage($user->id, $content, 'announcement');
            $count++;
        }

        // 3. Update sent_at = now(), sent_count = count
        $record->update([
            'sent_at' => now(),
            'sent_count' => $count,
        ]);

        return $record;
    }
}
