<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\AutomationResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\AutomationResource;

class CreateAutomation extends CreateRecord
{
    protected static string $resource = AutomationResource::class;
}
