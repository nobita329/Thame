<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin;

use Illuminate\Support\ServiceProvider;
use Filament\Facades\Filament;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\AutomationResource;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\AnnouncementResource;

class AdminServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Register Filament resources
        $this->app->booted(function () {
            Filament::registerResources([
                UserProfileResource::class,
                ProfileCommentResource::class,
                AutomationResource::class,
                AnnouncementResource::class,
            ]);
        });
    }
}