<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 mb-8">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 dark:bg-gradient-to-r dark:from-white dark:to-gray-300 dark:bg-clip-text dark:text-transparent flex items-center gap-3">
                <i class="ri-team-line text-blue-400"></i>
                Community Directory
            </h1>
            <p class="text-gray-500 dark:text-gray-400 mt-2">Discover other members, their profiles, and roles across the platform.</p>
        </div>

        <div class="flex flex-col sm:flex-row gap-3">
            <div class="relative">
                <input type="text" wire:model.debounce.300ms="search" placeholder="Search users..." 
                       class="w-full sm:w-64 px-4 py-2.5 bg-white dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700/70 text-gray-900 dark:text-white rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-gray-400 dark:placeholder-gray-500">
                <i class="ri-search-line absolute right-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
            </div>

            <div class="flex gap-2">
                <select class="px-3 py-2 bg-white dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700/70 text-sm text-gray-600 dark:text-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        wire:model.live="perPage">
                    <option value="12">12 / page</option>
                    <option value="24">24 / page</option>
                    <option value="48">48 / page</option>
                </select>

                <select class="px-3 py-2 bg-white dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700/70 text-sm text-gray-600 dark:text-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        wire:model.live="sort">
                    <option value="newest">Newest</option>
                    <option value="oldest">Oldest</option>
                    <option value="alphabetical">Alphabetical</option>
                </select>
            </div>
        </div>
    </div>

    @if($users->isEmpty())
        <div class="bg-white dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700/70 rounded-2xl p-12 text-center">
            <x-ri-user-unfollow-line class="w-16 h-16 text-gray-500 mx-auto mb-4" />
            <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">No users found</h2>
            <p class="text-gray-500 dark:text-gray-400">Try adjusting your search or filters to find more members.</p>
        </div>
    @else
        <div class="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
            @foreach($users as $user)
                @php
                    $profile = $profiles[$user->id] ?? null;
                @endphp
                <div class="bg-white dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700/70 rounded-2xl overflow-hidden shadow-lg shadow-black/10 hover:border-blue-500/60 hover:shadow-blue-500/10 transition-transform hover:-translate-y-1">
                    <div class="h-24 bg-gradient-to-r from-blue-600/20 to-purple-600/20">
                        @if($profile && $profile->banner_url)
                            <img src="{{ $profile->banner_url }}" alt="Banner" class="w-full h-full object-cover opacity-80">
                        @endif
                    </div>
                    <div class="-mt-10 px-6">
                        <div class="w-20 h-20 ring-4 ring-white dark:ring-gray-900 rounded-full overflow-hidden">
                            <img src="{{ $profile && $profile->avatar_url ? $profile->avatar_url : $user->avatar }}" alt="{{ $profile?->display_name ?? $user->name }}" class="w-full h-full object-cover">
                        </div>
                    </div>
                    <div class="px-6 pb-6 pt-4 space-y-3">
                        <div>
                            <h2 class="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                                {{ $profile?->display_name ?? $user->name }}
                            </h2>
                            <p class="text-sm text-blue-600 dark:text-blue-300">Joined {{ $user->created_at->format('M Y') }}</p>
                        </div>

                        @if($profile && $profile->bio)
                            <p class="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
                                {{ $profile->bio }}
                            </p>
                        @endif

                        <div class="flex flex-wrap gap-2 text-xs text-gray-500 dark:text-gray-400">
                            @if($profile && $profile->location)
                                <span class="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-gray-100 dark:bg-gray-700/70">
                                    <x-ri-map-pin-line class="w-3 h-3" /> {{ $profile->location }}
                                </span>
                            @endif
                            <span class="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-gray-100 dark:bg-gray-700/70">
                                <x-ri-discuss-line class="w-3 h-3" /> {{ $profile?->stats['comments_count'] ?? 0 }} comments
                            </span>
                        </div>

                        <div class="flex items-center gap-3 pt-2">
                            <a href="{{ route('socialbase.profile.show', ['user' => $user->id]) }}"
                               class="inline-flex items-center gap-2 px-3 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                               wire:navigate>
                                <x-ri-user-line class="w-4 h-4" /> View Profile
                            </a>

                            @if($profile && $profile->show_email)
                                <span class="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                                    <x-ri-mail-line class="w-3 h-3" /> {{ $user->email }}
                                </span>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="mt-8">
            {{ $users->onEachSide(1)->links('pagination::tailwind') }}
        </div>
    @endif
</div>

