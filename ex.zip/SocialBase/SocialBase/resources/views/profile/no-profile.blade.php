<div class="container mx-auto px-4 py-8">
    <div class="max-w-2xl mx-auto">
        <div class="bg-gray-800 rounded-xl p-8 text-center border border-gray-700/70 shadow-lg shadow-black/20">
            <div class="w-24 h-24 bg-gray-700 rounded-full mx-auto mb-6 flex items-center justify-center">
                <i class="ri-user-line text-4xl text-gray-400"></i>
            </div>

            <p class="text-gray-400 mb-6">This user hasn't set up their profile yet.</p>

            @php
                $ownsProfile = isset($isOwner) ? $isOwner : (Auth::check() && Auth::id() === $user->id);
            @endphp

            @if($ownsProfile)
                <a href="{{ route('socialbase.profile.edit') }}"
                   class="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors">
                    <i class="ri-edit-line"></i>
                    Set Up My Profile
                </a>
            @else
                <p class="text-sm text-gray-500">Check back later to see their profile!</p>
            @endif
        </div>
    </div>
</div>
