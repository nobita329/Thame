<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class UserDirectory extends Component
{
    use WithPagination;

    public $search = '';
    public $sort = 'newest';
    public $perPage = 12;
    public $page = 1;

    protected $queryString = [
        'search' => ['except' => ''],
        'sort' => ['except' => 'newest'],
        'page' => ['except' => 1],
        'perPage' => ['except' => 12],
    ];

    public function mount()
    {
        $socialBase = new \Paymenter\Extensions\Others\SocialBase\SocialBase();
        if (!$socialBase->config('enable_profiles')) {
             abort(404);
        }
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatedPerPage()
    {
        $this->resetPage();
    }

    public function updatedSort()
    {
        $this->resetPage();
    }

    public function setSort($sort)
    {
        $this->sort = $sort;
        $this->resetPage();
    }

    public function getUsersProperty()
    {
        $query = User::query()
            ->whereExists(function ($sub) {
                $sub->selectRaw('1')
                    ->from('ext_social_user_profiles as sup')
                    ->whereColumn('sup.user_id', 'users.id')
                    ->where('sup.is_public', true);
            })
            ->when($this->search, function ($q) {
                $term = '%' . $this->search . '%';
                $q->where(function ($builder) use ($term) {
                    $builder->where('first_name', 'like', $term)
                        ->orWhere('last_name', 'like', $term)
                        ->orWhere('email', 'like', $term)
                        ->orWhereExists(function ($sub) use ($term) {
                            $sub->selectRaw('1')
                                ->from('ext_social_user_profiles as sup')
                                ->whereColumn('sup.user_id', 'users.id')
                                ->where('sup.is_public', true)
                                ->where(function ($profileQuery) use ($term) {
                                    $profileQuery->where('sup.display_name', 'like', $term)
                                        ->orWhere('sup.location', 'like', $term);
                                });
                        });
                });
            });

        switch ($this->sort) {
            case 'oldest':
                $query->orderBy('created_at', 'asc');
                break;
            case 'alphabetical':
                $query->orderBy('first_name');
                break;
            default:
                $query->orderBy('created_at', 'desc');
        }

        $paginator = $query->paginate($this->perPage);

        $paginator->withPath(route('socialbase.profile.directory'))
            ->appends([
                'search' => $this->search ?: null,
                'sort' => $this->sort !== 'newest' ? $this->sort : null,
                'perPage' => $this->perPage !== 12 ? $this->perPage : null,
            ]);

        return $paginator;
    }

    public function render()
    {
        $users = $this->users;

        $profiles = UserProfile::whereIn('user_id', $users->pluck('id'))
            ->where('is_public', true)
            ->get()
            ->keyBy('user_id');

        return view('socialbase::livewire.user-directory', [
            'users' => $users,
            'profiles' => $profiles,
            'search' => $this->search,
            'sort' => $this->sort,
            'perPage' => $this->perPage,
            'page' => $this->page,
        ]);
    }
}


