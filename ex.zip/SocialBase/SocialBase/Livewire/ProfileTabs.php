<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Event;
use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class ProfileTabs extends Component
{
    public User $user;
    public UserProfile $profile;
    public $activeTab = 'overview';
    public $tabUrls = [];
    public $tabs = [];
    
    public function mount(User $user, UserProfile $profile)
    {
        $this->user = $user;
        $this->profile = $profile;
        
        // Get base tabs
        $this->tabs = [
            'overview' => [
                'label' => 'Overview',
                'icon' => 'ri-user-line',
                'content' => null, // Will be rendered in view
            ],
        ];
        
        // Get tabs from other extensions
        $extensionTabs = Event::dispatch('socialbase.profile.tabs', [$this->user]);
        
        // Process extension tabs - flatten() doesn't work well with associative arrays
        foreach ($extensionTabs as $tabResult) {
            if (is_array($tabResult) && isset($tabResult['key'], $tabResult['label'])) {
                $this->tabs[$tabResult['key']] = $tabResult;

                if (isset($tabResult['url'])) {
                    $this->tabUrls[$tabResult['key']] = $tabResult['url'];
                }
            }
        }
    }
    
    public function setActiveTab($tab)
    {
        if (array_key_exists($tab, $this->tabs)) {
            // If the tab specifies a URL, redirect instead of switching content inline
            if (isset($this->tabUrls[$tab])) {
                return redirect()->to($this->tabUrls[$tab]);
            }

            $this->activeTab = $tab;
        }
    }
    
    public function getTabContent($tab)
    {
        if ($tab === 'overview') {
            return null; // Handled in view
        }
        
        $content = Event::dispatch('socialbase.profile.content', [$this->user, $tab]);
        return collect($content)->filter()->first();
    }
    
    public function render()
    {
        return view('socialbase::livewire.profile-tabs', [
            'activeTabContent' => $this->getTabContent($this->activeTab)
        ]);
    }
}