<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;
use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class ProfileView extends Component
{
	public $user;
    public $profile;
    public $isOwner = false;
    public $canComment = false;
    public $canReact = false;
    public $availableReactions = [];
    public $messagingEnabled = true;
    
    public function mount($user)
    {
        $socialBase = new \Paymenter\Extensions\Others\SocialBase\SocialBase();
        if (!$socialBase->config('enable_profiles')) {
             abort(404);
        }
        $this->messagingEnabled = $socialBase->config('enable_messaging');

        // Convert string ID to User model
        if (is_string($user)) {
            $this->user = \App\Models\User::findOrFail($user);
        } else {
            $this->user = $user;
        }
        
        $currentUserId = Auth::id();
        $targetUserId = $this->user->id;

        if ($currentUserId !== null && $currentUserId === $targetUserId) {
            $this->profile = UserProfile::createForUser($targetUserId, true);
        } else {
            $this->profile = UserProfile::getForUser($targetUserId);
        }

        if (!$this->profile) {
            $this->dispatch('showNoProfile');
            return;
        }
        
        // Check if current user can view this profile
        $currentUser = Auth::user(); // This will be null for guest users
        if (!$this->profile->isViewableBy($currentUser)) {
            abort(403, 'This profile is private and you do not have permission to view it.');
        }
        
        $this->isOwner = $currentUserId !== null && $currentUserId === $targetUserId;
        $this->canComment = $currentUserId !== null && $currentUserId !== $targetUserId && $this->profile->allowsComments();
        $this->canReact = Auth::check() && !$this->isOwner && $this->profile->isViewableBy(Auth::user());
        $this->availableReactions = \Paymenter\Extensions\Others\SocialBase\Models\Reaction::getAvailableTypes('social');
    }
    
    public function render()
    {
        return view('socialbase::livewire.profile-view');
    }
}