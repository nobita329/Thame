<?php

namespace Paymenter\Extensions\Others\SocialBase\Listeners;

use App\Models\Notification;
use Illuminate\Support\Str;

class NotificationListener
{
    public function handle($message)
    {
        // $message is the Message model passed from Event::dispatch
        
        // If it's a system message, recipient is usually in the conversation
        // But for direct messages, we need to find the other participant
        
        // Get all participants except sender
        $participants = $message->conversation->participants()
            ->where('user_id', '!=', $message->sender_id)
            ->get();
            
        foreach ($participants as $participant) {
            $notification = new Notification();
            $notification->user_id = $participant->user_id;
            $notification->title = 'New Message';
            $notification->body = 'You have a new message from ' . ($message->sender ? $message->sender->name : 'System');
            $notification->url = route('socialbase.messages.conversation', $message->conversation_id);
            $notification->save();
        }
    }

    public function handleSystemMessage($message, $userId)
    {
        $notification = new Notification();
        $notification->user_id = $userId;
        $notification->title = 'New System Message';
        $notification->body = Str::limit($message->content, 100);
        $notification->url = route('socialbase.messages.conversation', $message->conversation_id);
        $notification->save();
    }
}
