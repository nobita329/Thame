<?php

namespace Paymenter\Extensions\Others\SocialBase\Listeners;

use App\Events\Invoice\Paid as InvoicePaid;
use App\Events\Order\Created as OrderCreated;
use App\Events\Service\Updated as ServiceUpdated;
use Paymenter\Extensions\Others\SocialBase\Models\Automation;
use Paymenter\Extensions\Others\SocialBase\Services\MessagingService;
use Illuminate\Support\Str;

class AutomationListener
{
    protected $messagingService;

    public function __construct()
    {
        $this->messagingService = new MessagingService();
    }

    public function handleInvoicePaid(InvoicePaid $event)
    {
        $this->processAutomations('invoice.paid', $event->invoice->user, [
            '{invoice_id}' => $event->invoice->id,
            '{amount}' => $event->invoice->total,
            '{currency}' => $event->invoice->currency,
        ]);
    }

    public function handleOrderCreated(OrderCreated $event)
    {
        $this->processAutomations('order.created', $event->order->user, [
            '{order_id}' => $event->order->id,
            '{total}' => $event->order->total,
        ]);
    }

    public function handleServiceUpdated(ServiceUpdated $event)
    {
        // Only trigger if service is active
        if ($event->service->status !== 'active') {
            return;
        }

        $this->processAutomations('service.activated', $event->service->order->user, [
            '{service_id}' => $event->service->id,
            '{service_name}' => $event->service->product->name,
            '{price}' => $event->service->price,
        ]);
    }

    protected function processAutomations($eventName, $user, $variables = [])
    {
        if (!$user) return;

        $automations = Automation::where('event', $eventName)
            ->where('is_active', true)
            ->get();

        // Add common variables
        $variables['{user_name}'] = $user->name;
        $variables['{user_id}'] = $user->id;
        $variables['{user_email}'] = $user->email;

        foreach ($automations as $automation) {
            /** @var Automation $automation */
            $subject = $this->replaceVariables($automation->template_subject, $variables);
            $content = $this->replaceVariables($automation->template_content, $variables);

            // Prepend subject to content as system messages don't have separate subject field usually
            $fullContent = "**{$subject}**\n\n{$content}";

            $this->messagingService->sendSystemMessage(
                $user->id,
                $fullContent,
                'automation'
            );
        }
    }

    protected function replaceVariables($text, $variables)
    {
        return str_replace(array_keys($variables), array_values($variables), $text);
    }
}
