<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('ext_social_conversation_participants', function (Blueprint $table) {
            $table->boolean('is_pinned')->default(false)->after('is_archived');
            $table->index('is_pinned');
        });
    }

    public function down()
    {
        Schema::table('ext_social_conversation_participants', function (Blueprint $table) {
            $table->dropColumn('is_pinned');
        });
    }
};

