<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            // Feature-specific restrictions
            $table->boolean('forum_restricted')->default(false)->after('comment_restricted');
            $table->boolean('review_restricted')->default(false)->after('forum_restricted');
            $table->boolean('wiki_restricted')->default(false)->after('review_restricted');
            $table->boolean('faq_restricted')->default(false)->after('wiki_restricted');
            $table->boolean('messaging_restricted')->default(false)->after('faq_restricted');
            
            // Timestamps for restrictions
            $table->timestamp('restricted_at')->nullable()->after('restriction_reason');
            $table->timestamp('restriction_expires_at')->nullable()->after('restricted_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            $table->dropColumn([
                'forum_restricted',
                'review_restricted',
                'wiki_restricted',
                'faq_restricted',
                'messaging_restricted',
                'restricted_at',
                'restriction_expires_at',
            ]);
        });
    }
};
