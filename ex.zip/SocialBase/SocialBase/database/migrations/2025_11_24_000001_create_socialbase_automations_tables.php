<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ext_social_automations', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('event');
            $table->json('conditions')->nullable();
            $table->string('template_subject');
            $table->text('template_content');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('ext_social_announcements', function (Blueprint $table) {
            $table->id();
            $table->string('subject');
            $table->text('content');
            $table->string('recipients_type');
            $table->json('recipients_data')->nullable();
            $table->timestamp('sent_at')->nullable();
            $table->integer('sent_count')->default(0);
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ext_social_announcements');
        Schema::dropIfExists('ext_social_automations');
    }
};
