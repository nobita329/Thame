Hello nobitayt,

Thanks for downloading **Blogs for Paymenter** vV2.3.0!

--------------------------------------------
Details
--------------------------------------------
Resource: Blogs for Paymenter
Resource ID: 77560
Version: vV2.3.0
Downloaded by: nobitayt (User ID: 531247)
Timestamp (epoch): 1776725600
BuiltByBit Download: true
--------------------------------------------

Installation 
--------------------------------------------
- Find the blogs-*.zip
- Go inside Your paymenter admin panel 
- Find extension, click on install - uplaod - and uplaod the blogs*.zip
- Enable the extension and you are good to go
- Dont forget to read the tutorial blog

Support
--------------------------------------------
Need help or have questions?

- BuiltByBit: Message me on BuiltByBit
- Discord: https://discord.gg/A6TJh5GdVg

Creator Page
--------------------------------------------
https://builtbybit.com/creators/cloee.528205/

Drop a Review — I really appreciate your support!
