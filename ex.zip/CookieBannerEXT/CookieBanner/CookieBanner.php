<?php

namespace Paymenter\Extensions\Others\CookieBanner;

use App\Classes\Extension\Extension;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\HtmlString;

#[ExtensionMeta(
    name: 'CookieBanner',
    description: 'The easiest cookie compliance banner',
    version: '1.0.0',
    author: 'JTD',
    url: 'https://justvikie.nl',
    icon: 'https://justvikie.nl/favicon.ico'
)]
class CookieBanner extends Extension
{
    public function getConfig($values = []): array
    {
        return [
            [
                'name' => 'source',
                'type' => 'select',
                'label' => 'Script Source',
                'description' => 'Choose the source for the cookieconsent script',
                'options' => [
                    'default' => 'jtdmedia/opensiteassets@main/cookieconsent.js',
                ],
                'required' => true,
                'value' => $values['source'] ?? 'default',
            ],
        ];
    }

    public function boot(): void
    {
        if (!request()->isMethod('GET')) return;

        $bodyScript = $this->getBodyScript();
        Event::listen('body', function () use ($bodyScript) {
            return ['view' => new HtmlString($bodyScript)];
        });
    }

    private function getBodyScript(): string
    {
        $scriptSrc = "https://cdn.jsdelivr.net/gh/jtdmedia/opensiteassets@main/cookieconsent.js";

        return <<<HTML
<script src="{$scriptSrc}" async></script>
HTML;
    }

    public function enabled(): void {}
    public function disabled(): void {}
    public function updated(): void {}
    public function install(): void {}

    private function getSetting(string $key, $default = null)
    {
        return $this->config($key, $default);
    }
}

